<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pendaftaran Penerbangan</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>
<div class="container">
    <div class="card mt-5">
        <div class="card-header bg-primary text-white">
            <h3 class="text-center">Form Pendaftaran Penerbangan</h3>
        </div>
        <div class="card-body">

        <form action="" method="post">
            <div class="mb-3">
                <label class="form-label">Nama Maskapai :</label>
                <input type="text" name="maskapai" class="form-control" required>
            </div>

            <div class="mb-3">
                <label class="form-label">Bandara Asal :</label>
                <select name="asal" class="form-select" required>
                    <?php
                    $bandara_asal = [
                        "Soekarno Hatta" => 65000,
                        "Husein Sastranegara" => 50000,
                        "Abdul Rachman Saleh" => 40000,
                        "Juanda" => 30000,
                    ];
                    ksort($bandara_asal);
                    foreach($bandara_asal as $asal => $pajak){
                        echo "<option value='$asal'>$asal</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Bandara Tujuan :</label>
                <select name="tujuan" class="form-select" required>
                    <?php
                    $bandara_tujuan = [
                        "Ngurah Rai" => 85000,
                        "Hasanuddin" => 70000,
                        "Inanwatan" => 90000,
                        "Sultan Iskandar Muda" => 60000,
                    ];
                    ksort($bandara_tujuan);
                    foreach($bandara_tujuan as $tujuan => $pajak){
                        echo "<option value='$tujuan'>$tujuan</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Harga Tiket :</label>
                <input type="number" name="harga" class="form-control" required>
            </div>

            <button type="submit" name="submit" class="btn btn-success w-100">Proses</button>
        </form>

        </div>
    </div>

<?php
if(isset($_POST['submit'])){
    $maskapai = $_POST['maskapai'];
    $asal = $_POST['asal'];
    $tujuan = $_POST['tujuan'];
    $harga = $_POST['harga'];
    $pajak_asal = $bandara_asal[$asal];
    $pajak_tujuan = $bandara_tujuan[$tujuan];
    $total_pajak = $pajak_asal + $pajak_tujuan;
    $total_harga = $harga + $total_pajak;
?>

    <div class="card mt-4">
        <div class="card-header bg-success text-white">
            <h5>Data Penerbangan</h5>
        </div>
        <div class="card-body">
            <p><strong>Tanggal :</strong> <?= date('d-m-Y') ?></p>
            <p><strong>Maskapai :</strong> <?= $maskapai ?></p>
            <p><strong>Asal Penerbangan :</strong> <?= $asal ?></p>
            <p><strong>Tujuan Penerbangan :</strong> <?= $tujuan ?></p>
            <p><strong>Harga Tiket :</strong> Rp<?= number_format($harga,0,",",".") ?></p>
            <p><strong>Total Pajak :</strong> Rp<?= number_format($total_pajak,0,",",".") ?></p>
            <p><strong>Total Harga Tiket :</strong> Rp<?= number_format($total_harga,0,",",".") ?></p>
        </div>
    </div>

<?php } ?>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
