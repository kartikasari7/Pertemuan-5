<?php include 'db.php'; 
$id = $_GET['id'];
$data = mysqli_query($conn, "SELECT * FROM krs WHERE id='$id'");
$row = mysqli_fetch_assoc($data);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit KRS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2 class="mb-4">Edit KRS</h2>
    <form method="POST">
        <div class="mb-3">
            <label>Mahasiswa</label>
            <select name="npm" class="form-control" required>
                <?php
                $mahasiswa = mysqli_query($conn, "SELECT * FROM mahasiswa");
                while ($m = mysqli_fetch_assoc($mahasiswa)) {
                    $selected = ($m['npm'] == $row['mahasiswa_npm']) ? "selected" : "";
                    echo "<option value='{$m['npm']}' $selected>{$m['nama']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="mb-3">
            <label>Mata Kuliah</label>
            <select name="kodemk" class="form-control" required>
                <?php
                $matakuliah = mysqli_query($conn, "SELECT * FROM matakuliah");
                while ($mk = mysqli_fetch_assoc($matakuliah)) {
                    $selected = ($mk['kodemk'] == $row['matakuliah_kodemk']) ? "selected" : "";
                    echo "<option value='{$mk['kodemk']}' $selected>{$mk['nama']} ({$mk['jumlah_sks']} SKS)</option>";
                }
                ?>
            </select>
        </div>
        <button type="submit" name="update" class="btn btn-primary">Update</button>
        <a href="index_krs.php" class="btn btn-secondary">Kembali</a>
    </form>

    <?php
    if (isset($_POST['update'])) {
        $npm = $_POST['npm'];
        $kodemk = $_POST['kodemk'];
        $update = mysqli_query($conn, "UPDATE krs SET mahasiswa_npm='$npm', matakuliah_kodemk='$kodemk' WHERE id='$id'");
        if ($update) {
            echo "<div class='alert alert-success mt-3'>Data berhasil diupdate.</div>";
        } else {
            echo "<div class='alert alert-danger mt-3'>Gagal update data.</div>";
        }
    }
    ?>
</body>
</html>
