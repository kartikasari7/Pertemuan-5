<?php include 'db.php'; ?>
<?php
$npm = $_GET['npm'];
$data = mysqli_query($conn, "SELECT * FROM mahasiswa WHERE npm='$npm'");
$row = mysqli_fetch_assoc($data);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Mahasiswa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2>Edit Mahasiswa</h2>
    <form method="POST">
        <div class="mb-3">
            <label>NPM</label>
            <input type="text" name="npm" class="form-control" value="<?= $row['npm'] ?>" readonly>
        </div>
        <div class="mb-3">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" value="<?= $row['nama'] ?>" required>
        </div>
        <div class="mb-3">
            <label>Jurusan</label>
            <select name="jurusan" class="form-control" required>
                <option value="Teknik Informatika" <?= ($row['jurusan'] == 'Teknik Informatika') ? 'selected' : '' ?>>Teknik Informatika</option>
                <option value="Sistem Operasi" <?= ($row['jurusan'] == 'Sistem Operasi') ? 'selected' : '' ?>>Sistem Operasi</option>
            </select>
        </div>
        <div class="mb-3">
            <label>Alamat</label>
            <textarea name="alamat" class="form-control" required><?= $row['alamat'] ?></textarea>
        </div>
        <button name="update" class="btn btn-primary">Update</button>
        <a href="index_mahasiswa.php" class="btn btn-secondary">Kembali</a>
    </form>

    <?php
    if (isset($_POST['update'])) {
        $nama = $_POST['nama'];
        $jurusan = $_POST['jurusan'];
        $alamat = $_POST['alamat'];

        $query = mysqli_query($conn, "UPDATE mahasiswa SET nama='$nama', jurusan='$jurusan', alamat='$alamat' WHERE npm='$npm'");
        echo $query ? "<div class='alert alert-success mt-3'>Data berhasil diupdate.</div>"
                    : "<div class='alert alert-danger mt-3'>Gagal: " . mysqli_error($conn) . "</div>";
    }
    ?>
</body>
</html>
