<?php
include 'db.php';
$npm = $_GET['npm'];

mysqli_query($conn, "DELETE FROM krs WHERE mahasiswa_npm='$npm'");

mysqli_query($conn, "DELETE FROM mahasiswa WHERE npm='$npm'");

header("Location: index_mahasiswa.php");
