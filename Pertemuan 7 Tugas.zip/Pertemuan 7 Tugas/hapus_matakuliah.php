<?php
include 'db.php';

$kodemk = $_GET['kodemk']; 
$kodemk = mysqli_real_escape_string($conn, $kodemk);

$cek = mysqli_query($conn, "SELECT * FROM krs WHERE matakuliah_kodemk = '$kodemk'");
if (mysqli_num_rows($cek) > 0) {
    echo "<script>alert('Tidak bisa menghapus karena data masih digunakan di tabel KRS'); window.location='index_matakuliah.php';</script>";
} else {
    // Lanjut hapus
    $hapus = mysqli_query($conn, "DELETE FROM matakuliah WHERE kodemk = '$kodemk'");
    if ($hapus) {
        echo "<script>alert('Data berhasil dihapus'); window.location='index_matakuliah.php';</script>";
    } else {
        echo "<script>alert('Gagal menghapus data'); window.location='index_matakuliah.php';</script>";
    }
}
?>
