<?php
    if (isset($_POST['simpan'])) {
        $kodemk = $_POST['kodemk'];
        $nama = $_POST['nama'];
        $jumlah_sks = $_POST['jumlah_sks'];

        $simpan = mysqli_query($conn, "INSERT INTO matakuliah (kodemk, nama, jumlah_sks) VALUES ('$kodemk', '$nama', '$jumlah_sks')");

        if ($simpan) {
            echo "<div class='alert alert-success mt-3'>Data berhasil ditambahkan.</div>";
        } else {
            echo "<div class='alert alert-danger mt-3'>Gagal menyimpan data: " . mysqli_error($conn) . "</div>";
        }
    }
    ?>

<!DOCTYPE html>
<html>
<head>
    <title>Tambah Mata Kuliah</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
    <h2 class="mb-4">Tambah Mata Kuliah</h2>
    <form method="POST">
        <div class="mb-3">
            <label>Kode MK</label>
            <input type="text" name="kodemk" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Nama Mata Kuliah</label>
            <input type="text" name="nama" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Jumlah SKS</label>
            <input type="number" name="jumlah_sks" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-success">Simpan</button>
        <a href="index_matakuliah.php" class="btn btn-secondary">Kembali</a>
</div>

    
