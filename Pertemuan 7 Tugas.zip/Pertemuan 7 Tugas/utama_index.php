<!DOCTYPE html>
<html>
<head>
    <title>Dashboard CRUD KRS</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        h2 {
            text-align: center;
            color: #343a40;
        }
        .list-group {
            max-width: 500px;
            margin: 30px auto;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            overflow: hidden;
        }
        .list-group-item {
            font-size: 1.1rem;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        .list-group-item:hover {
            background-color: #0d6efd;
            color: white;
            transform: translateX(5px);
        }
    </style>
</head>
<body class="container mt-5">
    <h2 class="mb-4">Dashboard Sistem KRS</h2>
    <div class="list-group">
        <a href="index_mahasiswa.php" class="list-group-item list-group-item-action">📄 Data Mahasiswa</a>
        <a href="index_matakuliah.php" class="list-group-item list-group-item-action">📘 Data Mata Kuliah</a>
        <a href="index_krs.php" class="list-group-item list-group-item-action">📚 Data KRS</a>
    </div>
</body>
</html>
